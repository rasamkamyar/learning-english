# Learning-english
## Some Features
### **Mobile First**

### 1-BEM Based 
![BEM Example](./ReadMe/BEM.png)

### 2-Variable
![Variable Example](./ReadMe/Variable.png)

### 3-Mixin
![Mixin Example](./ReadMe/Mixin.png)

### 4-Different Style
![Style Example](./ReadMe/style.png)

 
